<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Animal - Art Gallery</title>

    

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  </head>

  <body>
      <!-- Navigation -->
      <?php
      session_start();
      require_once("connections/connect.php");
    ?>
    <?php
    include_once ('components/nav.php');
    ?>

    

    <!-- Main Content -->
    <div class="container" style="padding-top: 120px;">
    
    <?php

    include_once ('components/registo_form.php');

    

    $nome = "";
    $email = "";
    $pass = ""; 
    $desc = "";
    


  if (isset($_POST['submit'])) 
    {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    //$pass = password_hash($_POST['pass'], PASSWORD_DEFAULT) ; 
    $pass = ($_POST['pass']) ; 
    $desc = $_POST['descricao'];
    $image = $_FILES['image']['name']; 


    if ($_POST["pass"] === $_POST["confpass"]) {

  	// image file directory
    $target = "img/".basename($image);
    
    $sql = "INSERT INTO equipa (nome, email, password, descricao, img)
    VALUES ('$nome', '$email', '$pass', '$desc', '$image')";
      if (mysqli_query($link, $sql)) {

        move_uploaded_file($_FILES['image']['tmp_name'], $target);
          echo "<script>window.location.href='login.php';
          </script>";
      }
      else {
        echo "" . $sql . "<br>" . mysqli_error($link);
      }
    }
    else {
      echo "<script>alert('Password não coincide!');window.location.href='registo.php';</script>";
      ?><div class="alert alert-primary" role="alert">
          This is a primary alert—check it out!
        </div>
      <?php
    }
  } 

    ?>

    <br>
    <br>

    </div>
  </body>
  </html>