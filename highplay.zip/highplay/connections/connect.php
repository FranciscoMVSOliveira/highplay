<?php
$hostname	=	"localhost";
$username	=	"root";
$password	=	"";
$bd	=	"highplay";
$link	=	mysqli_connect($hostname,	$username,
    $password, $bd)	or	die("Erro	na
										ligação.."	.	mysqli_connect_error());
mysqli_set_charset($link,	'utf8');