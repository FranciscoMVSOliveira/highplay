<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Animal - Art Gallery</title>

    

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  </head>

  <body>

      <!-- Navigation -->
      <?php
      session_start();
      require_once("connections/connect.php");
      
      include_once ('components/nav.php');
      ?>

    <!-- Main Content -->
    <div class="container" style="padding-top: 120px;">
    
    <?php
    
    include_once ('components/login_form.php');

   
    $email = "";
    $pass = ""; 
    

    if(isset($_POST['submit'])) {

        // username and password sent from form 
        
        
        $email = $_POST['email'];

        $pass = $_POST['pass'];



        /* -- Password Hash -- */

        /*$passsql = "SELECT password FROM equipa WHERE email = '$email'";
        $resultpass = mysqli_query($link,$passsql);
        $rowpass = mysqli_fetch_array($resultpass,MYSQLI_BOTH);
        $pa = $rowpass['password'];

        $passow = password_verify($_POST['pass'],$pa);*/

        

        
        $myuseremail = mysqli_real_escape_string($link,$email);
        $mypassword = mysqli_real_escape_string($link,$pass); 
        
        $sql = "SELECT id, nome, tipo, img FROM equipa WHERE email = '$myuseremail' and password = '$mypassword'";
        $result = mysqli_query($link,$sql);
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        $row = mysqli_fetch_array($result,MYSQLI_BOTH);
        $nome = $row['nome'];
        $id = $row['id'];
        $admin_user = $row['tipo'];
        $user_image = $row['img'];
        

        
        
        
        $count = mysqli_num_rows($result);
        
        // If result matched $myusername and $mypassword, table row must be 1 row
          
        if($count == 1) {
           
          $_SESSION['logged']=true;
          $_SESSION['login_user'] = $myuseremail;
          $_SESSION['login_id'] = $nome;
          $_SESSION['id'] = $id;
          $_SESSION['admin_user'] = $admin_user;
          $_SESSION['user_image'] = $user_image;
           
           echo "<script>window.location.href='index.php';
          </script>";
        }else {
          $_SESSION['logged']=false;
           $error = "Your Login Name or Password is invalid";
        }
     }
     
    ?>

    </div>
  </body>
  </html>