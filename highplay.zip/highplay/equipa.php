<!DOCTYPE html>
<html lang="en">

  <head>
  <?php
  include_once ('components/head.php');
  ?>
  </head>

  <body>

    <?php
    session_start();
    require_once("connections/connect.php");
    include_once ('components/nav.php');
  ?>

  <style>

  .img-responsive{
    height: 250px;
    width: 250px;
    border-radius: 70px;
    object-fit:cover;
  }

  .team-hover{
    height: 250px;
    width: 250px;
    border-radius: 70px;
  }

  .team-hover .desk div{
    height: 250px;
    width: 250px;
    border-radius: 70px;
    
  }
  .desk{
    height: 250px;
    width: 250px;
    border-radius: 70px;
    margin-top: 70px;
    
  }

  .team-title{
    margin-left: -50px;
    text-align: center;
  }

  .team-img{
    height: 250px;
    width: 250px;
    border-radius: 70px;
    object-fit:cover;
  }

  
  
  
  </style>

    <!-- Page Header -->
    <header class="masthead" style="background-image: url('img/team.jpg')">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="page-heading">
              <h1>Team</h1>
              <span class="subheading">The specialists.</span>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Post Content -->
    <div class="container">
      <div class="row">

      <?php

$nome = "";

if (isset($_SESSION['login_id'])) {

  $nome = $_SESSION['login_id'];

}
$s= "SELECT tipo FROM equipa WHERE nome = '$nome'";

$re = mysqli_query($link,$s);

$rower = mysqli_fetch_assoc($re);

$t = $rower['tipo'];

?>
      
<?php

$contar = "SELECT COUNT(id) FROM equipa WHERE membro = 1";

$sqlc = mysqli_query($link,$contar);

$rows = mysqli_fetch_array($sqlc,MYSQLI_ASSOC);

$y = $rows['COUNT(id)'];


$sqlmemb = "SELECT id,nome,descricao,img FROM equipa WHERE membro = '1'";

$resultcount = mysqli_query($link,$sqlmemb);


for ($x = 1; $x <= $y; $x++) {
  
$value = mysqli_fetch_array($resultcount,MYSQLI_BOTH);

$i = $value['id'];

$z = $value['nome'];

$desc = $value['descricao'];

$imagem = $value['img'];

$_SESSION['img_user'] = $imagem;


$posque = "SELECT tipo FROM equipa WHERE nome = '$z'";



$rpos = mysqli_query($link,$posque);




$rowerpos = mysqli_fetch_assoc($rpos);



$post = $rowerpos['tipo'];


//$rowimg = mysqli_fetch_array($result)

//echo $z;
$l = "";

 if ($post == 1){ 
  
  $l = 'Administrador';
  }elseif ($post == 0){
    
    $l = 'Membro';
    
  }
    
?>
<div class="col-md-4 col-sm-4">
                            <div class="team-member">
                                <div class="team-img">
                                
<img src="img/<?=$imagem;?>" alt="team member" class="img-responsive">
      	                          

                                </div>
                                <div class="team-hover">
                                    <div class="desk">                                        
                                        <p><?=$desc?></p>
                                    </div>

                                </div>
                            </div>
                            <div class="team-title">
                                <h5><?=$z?></h5>
                                <span><?=$l;?></span>
                            </div>
                        </div>
                        <?php

}

        ?>
      </div>
  </div>

<!-- Mostrar parte só de admin em equipa -->

      <div>
 

<div id="admin">

<?php
include_once ('components/user_list.php');
?>
</div>

<?php


if ($t == 1){
  ?>
<script>
 
 document.getElementById("admin").style.display = "block";

</script>

 <?php
} else {
?>

<script>
 
 document.getElementById("admin").style.display = "none";

</script>

<?php

}

?>

    <hr>

    <!-- Footer -->
    <?php
    include_once ('components/footer.php');
    ?>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/clean-blog.min.js"></script>

    <!-- Equipa custom template -->
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

  </body>

</html>
