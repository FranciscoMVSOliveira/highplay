<!DOCTYPE html>
<html lang="en">

  <head>

  

  <?php
  include_once ('components/head.php');
  ?>
  </head>

  <body>

  <!-- Navigation e Conecção à BD -->

  <?php
  
    include_once ('components/nav.php');
    
   
      require_once("connections/connect.php");
      
  ?>
    <!-- Page Header -->
    <header class="masthead" style="background-image: url('img/bufallo.jpg')">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1>Animal</h1>
              <span class="subheading">Art Gallery</span>
            </div>
          </div>
        </div>
      </div>
    </header>

    

    <!-- Main Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="post-preview">
            <a href="#">
              <h2 class="post-title">
                Man must explore, and this is exploration at its greatest
              </h2>          
              <h3 class="post-subtitle">
                Problems look mighty small from 150 miles up
              </h3>
            </a>
            <p class="post-meta">Posted by
              <a href="#">Animals</a>
              on September 24, 2018</p>
          </div>
          <hr>
          <div class="post-preview">
            <a href="#">
              <h2 class="post-title">
                I believe every human has a finite number of heartbeats. I don't intend to waste any of mine.
              </h2>
            </a>
            <p class="post-meta">Posted by
              <a href="#">Animals</a>
              on September 18, 2018</p>
          </div>
          <hr>
          <div class="post-preview">
            <a href="post.html">
              <h2 class="#">
                Science has not yet mastered prophecy
              </h2>
              <h3 class="post-subtitle">
                We predict too much for the next year and yet far too little for the next ten.
              </h3>
            </a>
            <p class="post-meta">Posted by
              <a href="#">Animals</a>
              on August 24, 2018</p>
          </div>
          <hr>
          <div class="post-preview">
            <a href="#">
              <h2 class="post-title">
                Failure is not an option
              </h2>
              <h3 class="post-subtitle">
                Many say exploration is part of our destiny, but it’s actually our duty to future generations.
              </h3>
            </a>
            <p class="post-meta">Posted by
              <a href="#">Animals</a>
              on July 8, 2018</p>
          </div>
          <hr>
          <!-- Pager -->
          <div class="clearfix">
            <a class="btn btn-primary float-right" href="#">Older Posts &rarr;</a>
          </div>
        </div>
      </div>
    </div>

    <hr>

<!-- Footer -->

<?php
    include_once ('components/footer.php');
?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/clean-blog.min.js"></script>

  </body>

</html>
