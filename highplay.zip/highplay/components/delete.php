<?php
include ('../connections/connect.php');

$id = $_GET['a'];
if (isset($_GET['a'])) {
    $deleteutilizadores = "DELETE FROM equipa WHERE id =" . $id;
    $result = $link->query($deleteutilizadores);

    header('Location: ../equipa.php');


};

/*$id2 = $_GET['id2'];
if (isset($_GET['id2'])) {
    $deleteplantas = "DELETE FROM p_planta WHERE idp_planta =" . $id2;
    $result = $link->query($deleteplantas);
    header('Location: ../perfil.php');

};

$id3 = $_GET['id3'];
if (isset($_GET['id3'])) {
    $deletedoenca = "DELETE FROM p_doenca WHERE idp_doenca =" . $id3;
    $result = $link->query($deletedoenca);
    header('Location: ../perfil.php');

};

$id4 = $_GET['id4'];
if (isset($_GET['id4'])) {
    $deletetratamento = "DELETE FROM p_tratamento WHERE idp_tratamento =" . $id4;
    $result = $link->query($deletetratamento);
    header('Location: ../perfil.php');

};*/

?>