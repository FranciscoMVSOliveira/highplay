<?php

include ('../connections/connect.php');

$a = $_GET['a'];
if (isset($_GET['a'])) {
    $promoutilizadores = "UPDATE equipa
    SET tipo = 1
    WHERE id =" . $a;
    $result = $link->query($promoutilizadores);

    header('Location: ../equipa.php');


};

$b = $_GET['b'];
if (isset($_GET['b'])) {
    $promoutilizadores = "UPDATE equipa
    SET membro = 1
    WHERE id =" . $b;
    $result = $link->query($promoutilizadores);

    header('Location: ../equipa.php');


};

$c = $_GET['c'];
if (isset($_GET['c'])) {
    $promoutilizadores = "UPDATE equipa
    SET membro = 0
    WHERE id =" . $c;
    $result = $link->query($promoutilizadores);

    header('Location: ../equipa.php');


};

$d = $_GET['d'];
if (isset($_GET['d'])) {
    $promoutilizadores = "UPDATE equipa
    SET tipo = 0
    WHERE id =" . $d;
    $result = $link->query($promoutilizadores);

    header('Location: ../equipa.php');


};
/*
$nome_planta = $_POST['nome_planta'];
$descricao_planta = $_POST['descricao_planta'];

if (isset($_POST['nome_planta'])) {
    $addplantas = " INSERT INTO p_planta(nome_planta, descricao) VALUES ('$nome_planta','$descricao_planta')";
   $result = $link->query($addplantas);
   header('Location: ../perfil.php');

};

$nome_doenca = $_POST['nome_doenca'];
$descricao_doenca = $_POST['descricao_doenca'];
$perigos = $_POST['perigos'];

if (isset($_POST['nome_doenca'])) {
    $addoenca = " INSERT INTO p_doenca(nome_doenca, descricao_doenca, perigos) VALUES ('$nome_doenca','$descricao_doenca', '$perigos')";
    $result = $link->query($addoenca);
    header('Location: ../perfil.php');

};


$nome = $_POST['nome'];
$objetivo = $_POST['objetivo'];
$receita = $_POST['receita'];
$ingredientes = $_POST['ingredientes'];

if (isset($_POST['nome'])) {
    $addtrata = " INSERT INTO p_tratamento(nome, objetivo, receita, ingredientes) VALUES ('$nome','$objetivo', '$receita', '$ingredientes')";
    $result = $link->query($addtrata);
    header('Location: ../perfil.php');

};
*/


?>