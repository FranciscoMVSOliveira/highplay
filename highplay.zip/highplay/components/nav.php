<!-- Navigation -->

<style>

  .navbar{
    background-color: red !important;
  }
  .dropbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}

#foto{
  width: 30px;
  float: right;
  border-radius: 15px;
  margin-top: -6px;
  margin-left: 15px;
}

</style>

<?php

session_start();
require_once("connections/connect.php");




if($_SESSION['logged']=true){  

  if(isset($_SESSION['login_user'])){
$user  = $_SESSION['login_user'];
$id = $_SESSION['login_id'];
$imggg = $_SESSION['user_image'];
}}
elseif($_SESSION['logged']=false){
  
  $user = '';
}




if(isset($user)){

  
  
  


  ?>
  
  <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand" href="index.php">Animal</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="sobre.php">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="equipa.php">Team</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contacto.php">Contact</a>
            </li>
            <li class="nav-item">
               <a class="nav-link">Hello <?=$id?><img src="img/<?=$imggg;?>" id="foto"/></a>
              
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="logout.php">Logout</a>
            </li>
            
          </ul>
        </div>
      </div>
    </nav>
    <?php
}
else {
  ?>

    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand" href="index.php">Animal</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="sobre.php">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="equipa.php">Team</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contacto.php">Contact</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
          </ul>
        </div>
      </div>
    </nav> 

  <?php
}

?>

