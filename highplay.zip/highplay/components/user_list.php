<?php

include_once ('connections/connect.php');

$query_users = "SELECT * FROM equipa";
$result = mysqli_query($link, $query_users);


?>

<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">
<hr>
<div class="container bootstrap snippet">
    <div class="row">
        <div class="col-lg-12">
            <div class="main-box no-header clearfix">
                <div class="main-box-body clearfix">
                    <div class="table-responsive">
                        <h1>Gerir Utilizadores</h1>
                        <table class="table user-list">
                            <thead>


                            <tr>
                                <th><span>Nome</span></th>
                                <th><span>Email</span></th>                                
                                <th><span>Promover</span></th>
                                <th><span>Incluir</span></th>
                                <th><span>Despromover</span></th>
                                <th><span>Excluir</span></th>
                                <th><span>Apagar</span></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php


                                // output data of each row
                                while($row = mysqli_fetch_assoc($result)) {


                                    echo '<tr>
                 <td scope="row">' . $row["nome"]. '</td>
                 <td>' . $row["email"] .'</td>'
               ?>

                                    
                                    <td><a class="btn-xl23"
                                           href="components/mod.php?a=<?=$row['id']?>">
                                            Promover a Administrador</a>
                                    </td>
                                    <td><a class="btn-xl23"
                                           href="components/mod.php?b=<?=$row['id']?>">
                                            Incluir na Equipa</a>
                                    </td>
                                    <td><a class="btn-xl23"
                                           href="components/mod.php?d=<?=$row['id']?>">
                                            Despromover Administrador</a>
                                    </td>
                                    <td><a class="btn-xl23"
                                           href="components/mod.php?c=<?=$row['id']?>">
                                            Excluir da Equipa</a>
                                    </td>
                                    <td><a class="btn-xl23"
                               href="components/delete.php?a=<?=$row['id']?>">
                               Apagar Utilizador</a>
                                
</td>
           </tr>

                                 <?php

                                }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>